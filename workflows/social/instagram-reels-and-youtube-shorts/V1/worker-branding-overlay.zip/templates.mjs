import { reelBeats, storyBeats, solutionHeading } from './storyboard.mjs';
export const DESIGN_VERSION=3;
export const escape=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const concepts={
 restaurant:{items:['THE MENU','TODAY’S SPECIAL','OPENING HOURS','FIND US'],page:'THE MENU',verb:'Update the menu.',close:'Keep the link.'},
 creator:{items:['MY WORK','LATEST RELEASE','SOCIALS','CONTACT'],page:'YOUR WORLD',verb:'Bring it together.',close:'Make it yours.'},
 studio:{items:['PROJECTS','ABOUT US','CONTACT','OUR WORK'],page:'YOUR STUDIO',verb:'Let the work lead.',close:'Make contact easy.'},
 events:{items:['THE LINE-UP','WHEN & WHERE','EVENT INFO','TICKET LINK'],page:'THE NEXT EVENT',verb:'Set the scene.',close:'Share one link.'},
 cocktail:{items:['THE MENU','OUR DRINKS','FIND US','OPENING HOURS'],page:'YOUR BAR',verb:'Show the character.',close:'Share your page.'},
 property:{items:['THE PHOTOS','THE DETAILS','THE LOCATION','CONTACT'],page:'THE PROPERTY',verb:'Make room for detail.',close:'Make contact easy.'},
};
const skins={editorial:'orbit',blueprint:'impact',spotlight:'paper'};
const skinFor=j=>skins[j.layout]||'orbit';
const logoFor=s=>s==='paper'?'logo.png':'logo-dark.png';
const arrow='<svg class="direction" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M5 19 19 5M6 5h13v13" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const words=t=>String(t).split(/\s+/).map((w,i)=>`<span class="word word-${i}">${escape(w)}</span>`).join(' ');
const css=`
@font-face{font-family:InterTight;src:url('assets/inter-tight.woff2') format('woff2');font-weight:100 900;font-display:block}
*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1350px;overflow:hidden;background:#101828;font-family:InterTight,sans-serif;color:#f4f6f9}
:root{--ink:#101828;--blue:#2456d8;--paper:#f4f6f9;--pale:#7ba2ff}
.canvas{position:relative;width:100%;height:100%;overflow:hidden;background:var(--ink);color:var(--paper);isolation:isolate}.impact{background:var(--blue)}.paper{background:var(--paper);color:var(--ink)}
.brand{position:absolute;left:76px;top:76px;width:320px;height:67px;z-index:20}.top-meta{position:absolute;right:104px;top:96px;max-width:540px;font-size:28px;font-weight:650;letter-spacing:1.2px;text-align:right;z-index:20}
.eyebrow{position:absolute;left:78px;top:217px;width:850px;font-size:28px;line-height:1.15;font-weight:650;letter-spacing:2.4px;text-transform:uppercase}
.headline{position:absolute;left:72px;top:278px;width:920px;max-height:440px;margin:0;font-size:128px;font-weight:840;line-height:.96;letter-spacing:-.045em;z-index:5}
.direction{width:1em;height:1em;display:inline-block;vertical-align:middle;overflow:visible}.word{display:inline-block;position:relative;vertical-align:top}.headline .word:last-child,.close-heading .word:last-child{color:var(--pale)}.paper .headline .word:last-child,.paper .close-heading .word:last-child{color:var(--blue)}.impact .headline .word:last-child,.impact .close-heading .word:last-child{color:var(--paper);background:var(--ink);border-radius:12px;padding:0 14px 8px}
.detail{position:absolute;left:80px;top:745px;width:850px;font-size:36px;line-height:1.2;font-weight:450;z-index:5;margin:0}
.footer{position:absolute;left:80px;right:110px;bottom:76px;display:flex;justify-content:space-between;align-items:center;font-size:30px;font-weight:650;z-index:20}.footer .arrow{font-size:42px;line-height:1}.footer .count{font-size:28px;font-weight:500}
.orbital{position:absolute;left:-220px;top:740px;width:1460px;height:810px;border:3px solid #7ba2ff55;border-radius:50%;z-index:0}.orbital.two{left:-130px;top:805px;width:1320px;height:690px}.paper .orbital{border-color:#2456d833}.impact .orbital{border-color:#f4f6f94d}
.orbit-dot{position:absolute;left:850px;top:1030px;width:28px;height:28px;border-radius:50%;background:var(--pale);z-index:3}.paper .orbit-dot{background:var(--blue)}.corner-rule{position:absolute;left:78px;top:174px;width:920px;height:3px;background:currentColor;opacity:.25;transform-origin:left center}
.graphic{position:absolute;left:90px;top:930px;width:850px;height:660px;z-index:3;perspective:1400px}
.tile{position:absolute;width:530px;height:140px;padding:37px 38px;background:var(--paper);color:var(--ink);border:3px solid var(--ink);border-radius:20px;box-shadow:12px 15px 0 #07101f50;font-size:43px;line-height:1.05;font-weight:750;letter-spacing:-1.3px;display:flex;justify-content:space-between;align-items:center}.tile .tile-dot{width:20px;height:20px;flex:none;border:3px solid currentColor;border-radius:50%;margin-left:18px}
.tile-0{left:3px;top:6px}.tile-1{left:260px;top:145px;background:#7ba2ff}.tile-2{left:22px;top:284px}.tile-3{left:249px;top:423px}.impact .tile{box-shadow:13px 15px 0 #10182866}.paper .tile{box-shadow:12px 15px 0 #2456d829}.paper .tile-2{background:var(--blue);color:var(--paper)}
.orbit .tile{width:360px;height:150px;font-size:35px;padding:30px}.orbit .tile-0{left:0;top:0}.orbit .tile-1{left:440px;top:10px}.orbit .tile-2{left:0;top:370px}.orbit .tile-3{left:440px;top:390px}.central-hub{position:absolute;left:328px;top:205px;width:190px;height:190px;border:3px solid #101828;background:#f4f6f9;border-radius:50%;display:grid;place-items:center;z-index:7;box-shadow:12px 15px 0 #07101f66}.central-hub img{width:124px;height:124px}.orbit .stamp{right:60px;top:230px;width:145px;height:145px;font-size:30px}
.impact .tile{width:730px;height:130px;font-size:50px}.impact .tile-0{left:10px;top:0}.impact .tile-1{left:55px;top:160px}.impact .tile-2{left:0;top:320px}.impact .tile-3{left:50px;top:480px}.impact .stamp{right:-20px;top:215px}
.paper .tile{width:650px;height:150px;font-size:49px}.paper .tile-0{left:65px;top:0}.paper .tile-1{left:0;top:165px}.paper .tile-2{left:145px;top:330px}.paper .tile-3{left:45px;top:495px}.paper .stamp{right:-5px;top:185px}
.hero-page{position:absolute;left:100px;top:0;width:560px;height:620px;background:var(--paper);color:var(--ink);border:3px solid var(--ink);border-radius:30px;box-shadow:20px 24px 0 #07101f55;overflow:hidden;z-index:4}.hero-head{height:122px;padding:34px 35px;display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid var(--ink);font-size:30px;font-weight:750;letter-spacing:2px}.hero-mark{width:58px;height:58px;object-fit:contain}.hero-title{font-size:57px;font-weight:800;letter-spacing:-2px;margin:34px 36px 24px;line-height:1.0}
.hero-row{margin:0 35px 13px;padding:16px 22px;background:#e4ebfb;border-radius:12px;font-size:32px;font-weight:650;display:flex;justify-content:space-between;align-items:center}.hero-row:nth-last-child(2){background:var(--blue);color:var(--paper)}.hero-row span:last-child{font-size:29px}.hero-caption{position:absolute;left:38px;bottom:26px;font-size:32px;font-weight:600;letter-spacing:1px}
.qr-plate{position:absolute;left:680px;top:340px;background:var(--paper);padding:16px;border-radius:18px;border:3px solid var(--ink);box-shadow:9px 11px 0 #10182855;z-index:7;width:190px;height:230px}.qr-plate img{display:block;width:152px;height:152px}.qr-plate span{display:block;text-align:center;font-size:28px;color:var(--ink);font-weight:750;margin-top:9px}
.graphic-note{position:absolute;left:8px;top:660px;width:800px;font-size:31px;line-height:1;font-weight:700;letter-spacing:1px;text-align:center}.stamp{position:absolute;right:22px;top:2px;width:158px;height:158px;border-radius:50%;background:var(--blue);color:var(--paper);border:3px solid var(--paper);display:grid;place-items:center;font-size:32px;font-weight:750;line-height:1.05;text-align:center;letter-spacing:1px;z-index:8}.impact .stamp{background:var(--ink)}.paper .stamp{border-color:var(--ink)}
.poster .headline{top:235px;font-size:114px;max-height:335px}.poster .eyebrow{top:176px;font-size:23px}.poster .detail{top:1050px;width:800px;font-size:31px}.poster .graphic{top:605px;left:90px;height:440px;transform:scale(.60);transform-origin:top center}.poster .graphic-note{display:none}.poster .orbital{top:490px}.poster .orbital.two{top:580px}.poster .brand-close{top:765px;width:735px;left:165px}.poster .cta-box{top:1090px}.poster .close-heading{top:260px;font-size:155px}.poster.concept-1 .headline,.poster.concept-2 .headline{font-size:100px;max-height:335px}.poster.concept-1 .graphic,.poster.concept-2 .graphic{top:620px}
.reel{height:1920px}.reel .headline{min-height:130px}.reel .footer{bottom:200px}.reel .graphic{top:930px}.reel .orbital{top:870px}.reel .orbital.two{top:960px}.reel .graphic-note{top:650px;font-size:30px}.reel.scene-1 .headline{font-size:108px;line-height:1.0;max-height:390px}.reel.scene-1 .detail{top:720px;font-size:33px}.reel.scene-1 .graphic{top:895px}.reel.scene-1 .graphic-note{top:664px}
.close-heading{position:absolute;left:74px;top:285px;width:880px;font-size:164px;font-weight:850;line-height:.92;letter-spacing:-.04em;margin:0;z-index:5}.brand-close{position:absolute;left:155px;top:1080px;width:735px;height:auto;z-index:5}.brand-disc{position:absolute;left:176px;top:820px;width:690px;height:690px;border:3px solid #7ba2ff55;border-radius:50%}.brand-disc.two{left:91px;top:735px;width:860px;height:860px;border-color:#7ba2ff33}.paper .brand-disc{border-color:#2456d833}
.cta-box{position:absolute;left:80px;top:1420px;width:850px;padding:32px 38px;display:flex;justify-content:space-between;border:3px solid currentColor;border-radius:18px;font-size:42px;line-height:1.1;font-weight:650;z-index:5;background:var(--blue);color:var(--paper)}.impact .cta-box{background:var(--paper);color:var(--ink)}
.progress{position:absolute;left:80px;bottom:165px;width:850px;height:5px;background:currentColor;transform-origin:left center;z-index:20}.clip{position:absolute;inset:0}.stage{position:absolute;inset:0;overflow:hidden}.motion-wipe{position:absolute;inset:0;background:var(--blue);z-index:15;transform-origin:top center}.impact .motion-wipe{background:var(--ink)}
`;
const storyCSS=`.reel.beat-setup .graphic{top:1000px}.reel.beat-setup .tile{left:0;width:800px;height:120px;font-size:45px;padding:25px 36px}.reel.beat-setup .tile-0{top:0}.reel.beat-setup .tile-1{top:148px}.reel.beat-setup .tile-2{top:296px}.reel.beat-setup .tile-3{top:444px}.reel.beat-setup .central-hub{display:none}.reel.beat-setup .stamp{right:-8px;top:450px;width:125px;height:125px;font-size:32px}.reel.beat-solution .graphic{top:930px}.reel.beat-friction .graphic{transform:scale(1.03);transform-origin:center}.reel.beat-turn .headline{font-size:116px}.reel.beat-cta .cta-box{font-size:40px}`;
const background=()=>'<div class="orbital" data-layout-ignore></div><div class="orbital two" data-layout-ignore></div><div class="orbit-dot" data-layout-ignore></div><div class="corner-rule"></div>';
const brand=(j,s,id='poster')=>`<img id="${id}-brand" class="brand" src="assets/${logoFor(s)}" alt="Example demo logo"><div class="top-meta">${escape(j.feature.audience.toUpperCase())}</div>`;
const footer=(j,i,reel=false)=>`<div class="footer"><span>example.com</span><span class="count">${reel?'YOUR PAGE. YOUR WAY.':`${String(i+1).padStart(2,'0')} / ${j.postType==='single'?'01':'04'}`}</span><span class="arrow">${arrow}</span></div>`;
function graphic(j,stage,showNote=true,showStamp=true){
 const c=concepts[j.feature.id]||concepts.creator;
 const tiles=c.items.map((t,i)=>`<div class="tile tile-${i}"><span>${escape(t)}</span><span class="tile-dot"></span></div>`).join('');
 const page=`<div class="hero-page"><div class="hero-head"><span>ONE PAGE</span><img id="page-mark" class="hero-mark" src="assets/mark.svg" alt=""></div><div class="hero-title">${escape(c.page)}</div>${c.items.slice(0,3).map(t=>`<div class="hero-row"><span>${escape(t)}</span><span>${arrow}</span></div>`).join('')}<div class="hero-caption">YOUR CONTENT. ONE PLACE.</div></div>`;
 const qr=j.feature.id==='restaurant'?'<div class="qr-plate"><img src="assets/qr-menu.svg" alt="QR code to the Example menu demo"><span>SAME LINK</span></div>':'';
 return `<div class="graphic" data-layout-allow-overflow data-graphic-stage="${stage}">${stage===0?tiles:page}${stage===0?(skinFor(j)==='orbit'?'<div class="central-hub"><img src="assets/mark.svg" alt="Example official mark"></div>':'')+(showStamp?'<div class="stamp"><span>ONE</span><span>PLACE</span></div>':''):qr}${showNote?`<div class="graphic-note">${escape(stage===0?c.verb:c.close)}</div>`:''}</div>`;
}
const fit=`for(const el of document.querySelectorAll('.headline')){const limit=parseFloat(getComputedStyle(el).maxHeight);while((el.scrollHeight>limit+2||el.scrollWidth>el.clientWidth+2)&&parseFloat(getComputedStyle(el).fontSize)>68)el.style.fontSize=(parseFloat(getComputedStyle(el).fontSize)-2)+'px';}`;
function doc(body){return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=1080,height=1350"><title>Example creative studio</title><style>${css}</style></head><body>${body}<script>${fit}for(const [i,t] of [...document.querySelectorAll('.tile')].entries())t.style.transform='rotate('+[-10,8,-5,9][i%4]+'deg)';</script></body></html>`;}
export function postHTML(j,i){
 const s=skinFor(j);
 if(i===3)return doc(`<main class="canvas poster ${s}">${background()}${brand(j,s)}<div class="eyebrow">${escape(j.feature.category)}</div><h1 class="close-heading">Make it yours.</h1><img id="brand-reveal" class="brand-close" src="assets/${logoFor(s)}" alt="Example demo logo"><div class="cta-box"><span>Explore example.com</span><span>${arrow}</span></div>${footer(j,i)}</main>`);
 const story=storyBeats(j),heading=i===0?j.copy.hook:i===1?story[0].heading:solutionHeading(j),detail=i===0?j.copy.detail:i===1?story[1].line:j.copy.detail;
 return doc(`<main class="canvas poster concept-${i} ${s}">${background()}${brand(j,s)}<div class="eyebrow">${escape(j.feature.category)}</div><h1 class="headline">${words(heading)}</h1>${graphic(j,i<2?0:1)}<p class="detail">${escape(detail)}</p>${footer(j,i)}</main>`);
}
export function reelHTML(j){
 const s=skinFor(j),beats=reelBeats(j),starts=[0,3.5,8,12.5,17,22.5],durations=[3.5,4.5,4.5,4.5,5.5,4],timing=j.narration?.cues||starts.map((sceneStart,i)=>({sceneStart,sceneDuration:durations[i],start:sceneStart+.25,end:sceneStart+durations[i]-.5})),duration=j.narration?.duration||26.5;
 const actJobs=beats.map((b,i)=>({...j,layout:i===3?'editorial':i===2?(s==='paper'?'editorial':'spotlight'):j.layout}));
 const headings=beats.map(b=>b.heading),details=beats.map((b,i)=>i===0?(concepts[j.feature.id]||concepts.creator).close:i===5?'':b.line);
 const scenes=timing.map((cue,i)=>{const act=actJobs[i],tone=skinFor(act);return `<section id="scene-${i}" class="clip" data-start="${cue.sceneStart}" data-duration="${cue.sceneDuration}" data-track-index="${i}"><div class="stage canvas reel scene-${i} beat-${beats[i].role} ${tone}">${background()}${brand(act,tone,'scene-'+i)}<div class="eyebrow">${escape(i===5?'YOUR NEXT STEP':j.feature.category)}</div>${i===5?`<h1 class="close-heading">${words(headings[i])}</h1><div class="brand-disc"></div><div class="brand-disc two"></div><img id="brand-reveal" class="brand-close" src="assets/${logoFor(tone)}" alt="Example demo logo"><div class="cta-box"><span>Explore example.com</span><span>${arrow}</span></div>`:`<h1 class="headline">${words(headings[i])}</h1><p class="detail">${escape(details[i])}</p>${graphic(act,i===4?1:0,i===0||i===4,false)}`}<div class="progress"></div>${footer(j,i,true)}<div class="motion-wipe" data-layout-allow-overflow></div></div></section>`;}).join('');
 const points=[{t:0,v:.55}];for(const c of timing){points.push({t:Math.max(0,c.start-.12),v:.55},{t:c.start,v:.15},{t:c.end,v:.15});if(c.end+.16<duration)points.push({t:c.end+.16,v:.55});}points.push({t:duration-.18,v:.55},{t:duration,v:0});
 const automation=escape(JSON.stringify({version:1,lanes:[{target:'volume',points}]}));
 const master=escape(JSON.stringify({version:1,nodes:[{type:'limiter',id:'ceiling',label:'Voice-first mix ceiling',params:{limit:-2,attack:5,release:50,level_out:0}}]}));
 const voice=j.narration?`<audio data-audio-group="master-mix" id="english-narration" src="voiceover.wav" data-start="0" data-duration="${duration}" data-volume="1" data-track-index="11"></audio>`:'';
 const sting=`<audio data-audio-group="master-mix" id="brand-sting" src="assets/brand-land.wav" data-start="${duration-.55}" data-duration="0.45" data-volume="0.85" data-track-index="14"></audio>`;
 const sounds=timing.map((c,i)=>`<audio data-audio-group="master-mix" id="land-${i}" src="assets/land.wav" data-start="${c.sceneStart+.02}" data-duration="0.45" data-volume="0.35" data-track-index="12"></audio>${i?`<audio data-audio-group="master-mix" id="transition-${i}" src="assets/transition.wav" data-start="${c.sceneStart-.16}" data-duration="0.4" data-volume="0.35" data-track-index="13"></audio>`:''}`).join('');
 const offsets=s==='impact'?[[-30,-15,-7],[40,0,5],[-20,10,-4],[20,15,6]]:s==='paper'?[[-15,0,-7],[20,0,7],[-10,10,-4],[20,15,5]]:[[-15,-20,-12],[35,10,7],[-30,20,-8],[10,35,10]];
 const script=`
const timing=${JSON.stringify(timing)},skins=${JSON.stringify(actJobs.map(skinFor))};
const tl=gsap.timeline({paused:true});
timing.forEach((c,i)=>{
 const start=c.sceneStart,d=c.sceneDuration,r='#scene-'+i,skin=skins[i];
 const offsets=skin==='impact'?[[-30,-15,-7],[40,0,5],[-20,10,-4],[20,15,6]]:skin==='paper'?[[-15,0,-7],[20,0,7],[-10,10,-4],[20,15,5]]:[[-15,-20,-12],[35,10,7],[-30,20,-8],[10,35,10]];
 const base=skin==='orbit'?[[0,0],[440,10],[0,370],[440,390]]:skin==='impact'?[[10,0],[55,160],[0,320],[50,480]]:[[65,0],[0,165],[145,330],[45,495]];
 tl.fromTo(r+' .word',{y:55,x:i===1?-24:24,opacity:.35,rotation:i===1?-3:1},{y:0,x:0,opacity:1,rotation:0,duration:.42,stagger:.055,ease:'power4.out'},start);
 tl.fromTo(r+' .corner-rule',{scaleX:.05},{scaleX:1,duration:.7,ease:'expo.out'},start+.1);
 tl.fromTo(r+' .orbital',{rotation:i===1?-12:-26,scale:.94},{rotation:i===1?28:8,scale:1.09,duration:d,ease:'none'},start);
 tl.fromTo(r+' .orbit-dot',{x:-50,y:-100},{x:-160,y:230,duration:d,ease:'sine.inOut'},start);
 if(i<5)tl.fromTo(r+' .detail',{y:24,opacity:0},{y:0,opacity:1,duration:.4,ease:'power2.out'},start+.32);
 tl.fromTo(r+' .progress',{scaleX:0},{scaleX:1,duration:d,ease:'none'},start);
 if(i===0||i===2||i===3){
  offsets.forEach((p,n)=>{
   const t=r+' .tile-'+n;
   tl.fromTo(t,{x:p[0]+(n%2?330:-330),y:p[1]+80,rotation:p[2]*2,scale:.8,opacity:.1},{x:p[0],y:p[1],rotation:p[2],scale:1,opacity:1,duration:.65,ease:'back.out(1.25)'},start+.18+n*.15);
   tl.to(t,{x:p[0]+(n%2?-34:28),y:p[1]-42,rotation:p[2]*.55,duration:1.25,ease:'sine.inOut'},start+1.5+n*.18);
   tl.to(t,{x:skin==='orbit'?243-base[n][0]:n%2?-30:40,y:skin==='orbit'?245-base[n][1]:p[1]-75,scale:skin==='orbit'?.3:.9,opacity:skin==='orbit'?0:1,duration:.7,ease:'power3.inOut'},start+d-1.0);
  });
  if(skin==='orbit')tl.fromTo(r+' .central-hub',{scale:.65,rotation:-15},{scale:1,rotation:0,duration:.7,ease:'back.out(1.5)'},start+.4);
 }else if(i===1){
  tl.fromTo(r+' .tile',{x:-260,opacity:.1,rotation:-8},{x:0,opacity:1,rotation:0,duration:.6,stagger:.22,ease:'power3.out'},start+.2);
  tl.to(r+' .tile',{x:24,duration:.8,stagger:.18,yoyo:true,repeat:1,ease:'sine.inOut'},start+1.6);
  if(skin==='orbit')tl.to(r+' .central-hub',{scale:1.1,duration:.4,yoyo:true,repeat:1},start+2);
 }else if(i===4){
  tl.fromTo(r+' .hero-page',{y:180,rotation:-11,scale:.75},{y:0,rotation:0,scale:1,duration:.75,ease:'expo.out'},start+.12);
  tl.fromTo(r+' .hero-row',{x:90,opacity:.15},{x:0,opacity:1,duration:.45,stagger:.22,ease:'power3.out'},start+.65);
  tl.to(r+' .hero-page',{y:-18,rotation:2,scale:1.045,duration:1.4,ease:'sine.inOut'},start+2);
  if(${j.feature.id==='restaurant'})tl.fromTo(r+' .qr-plate',{x:140,rotation:18,scale:.6,opacity:0},{x:0,rotation:-6,scale:1,opacity:1,duration:.6,ease:'back.out(1.5)'},start+1.55);
 }else{
  tl.fromTo(r+' .brand-close',{y:80,scale:.65,rotation:-7,opacity:.2},{y:0,scale:1,rotation:0,opacity:1,duration:.8,ease:'expo.out'},start+.1);
  tl.fromTo(r+' .brand-disc',{scale:.4,rotation:-35},{scale:1,rotation:12,duration:1.5,stagger:.15,ease:'power3.out'},start);
  tl.fromTo(r+' .cta-box',{x:-180,opacity:0},{x:0,opacity:1,duration:.5,ease:'back.out(1.2)'},start+1.15);
  tl.to(r+' .brand-close',{scale:1.025,duration:.16,yoyo:true,repeat:1,ease:'power2.out'},start+d-.65);
  tl.to(r+' .cta-box',{x:12,duration:.2,yoyo:true,repeat:1,ease:'power2.inOut'},start+2.5);
 }
 if(i===0||i===4)tl.fromTo(r+' .graphic-note',{y:25,opacity:0},{y:0,opacity:1,duration:.35,ease:'power3.out'},start+1.5);
 tl.fromTo(r+' .motion-wipe',{scaleY:i?1:0},{scaleY:0,duration:i?.28:.001,ease:'power4.out'},start);
});window.__timelines['main']=tl;`;
 return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Example motion creative</title><script src="assets/gsap.min.js"></script><style>${css.replaceAll('height:1350px','height:1920px')}${storyCSS}html,body{height:1920px}#root{position:relative;width:100%;height:100%;overflow:hidden}</style></head><body><div id="root" data-composition-id="main" data-width="1080" data-height="1920" data-duration="${duration}" data-fps="24">${scenes}<hf-audio-group id="master-mix" data-fx-chain="${master}"></hf-audio-group><audio data-audio-group="master-mix" id="original-sound" src="assets/motion-bed.wav" data-start="0" data-duration="${duration}" data-volume="1" data-automation="${automation}" data-track-index="10"></audio>${voice}${sounds}${sting}</div><script>${fit}${script}</script></body></html>`;
}
