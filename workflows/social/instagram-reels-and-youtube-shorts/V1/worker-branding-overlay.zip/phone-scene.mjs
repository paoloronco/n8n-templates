const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// Physical shell adapted from HyperFrames' device-frame-stage primitive.
// The screen shows one unmodified native page; no parallel detail/dashboard crop.
export const phoneSceneCSS=`
@font-face{font-family:StudioSans;src:url('assets/inter-tight.woff2') format('woff2');font-weight:100 900;font-display:block}
*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1350px;font-family:StudioSans,sans-serif}
.canvas{position:relative;width:1080px;height:1350px;overflow:hidden;background:#f1f3f8;color:#102039;--accent:#315deb;--phone-width:410px;--phone-left:555px;--phone-top:240px;--phone-angle:-3deg}
.canvas:before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 78% 68%,#c7d6ee 0,transparent 59%);pointer-events:none}
.canvas.ink{background:#101b2c;color:#f7f7f4}.canvas.ink:before{background:radial-gradient(ellipse at 65% 65%,#263d5b 0,transparent 64%)}
.canvas.blue{background:#2a55d0;color:#f7f7f4}.canvas.blue:before{background:radial-gradient(ellipse at 60% 66%,#4a73dd 0,transparent 62%)}
.reel{height:1920px;--phone-width:465px;--phone-left:475px;--phone-top:520px}
.brand{position:absolute;left:80px;top:82px;width:290px;height:auto}.reel .brand{top:184px}
.headline{position:absolute;left:80px;top:350px;width:400px;font-size:84px;line-height:1.02;letter-spacing:-.04em;font-weight:780;margin:0;padding-bottom:.14em;text-wrap:balance}
.detail{position:absolute;left:80px;top:880px;width:380px;font-size:32px;line-height:1.3;margin:0;opacity:.8}
.reel .headline{top:590px;width:335px;font-size:68px}.reel .detail{top:1160px;width:335px;font-size:36px}
.phone-left{--phone-left:95px;--phone-top:270px;--phone-width:415px;--phone-angle:3deg}
.phone-left .headline{left:575px;top:400px;width:400px;font-size:84px}.phone-left .detail{left:575px;top:900px;width:385px}
.reel.phone-left{--phone-left:110px;--phone-top:520px;--phone-width:440px}.reel.phone-left .headline{left:625px;top:610px;width:320px;font-size:68px}.reel.phone-left .detail{left:625px;top:1180px;width:310px}
.phone-center{--phone-left:365px;--phone-top:475px;--phone-width:350px;--phone-angle:0deg}
.phone-center .headline{left:80px;top:230px;width:920px;font-size:72px}.phone-center .detail{display:none}
.reel.phone-center{--phone-left:290px;--phone-top:600px;--phone-width:470px;--phone-angle:-2deg}.reel.phone-center .headline{left:80px;top:315px;width:850px;font-size:80px}
.device-stage{position:absolute;left:var(--phone-left);top:var(--phone-top);width:var(--phone-width);aspect-ratio:9/19.5;perspective:1800px}
.device-ground{position:absolute;left:-18%;right:-18%;bottom:-36px;height:65px;background:#07132650;border-radius:50%;filter:blur(25px);transform:scaleY(.65)}
.phone-body{position:absolute;inset:0;padding:10px;border:2px solid #c4c9d1;border-radius:58px;background:linear-gradient(135deg,#adb5bf,#545b65 18%,#14171c 43%,#787f89 86%,#c1c8d0);box-shadow:0 40px 65px #060e2140,0 10px 18px #060e2130,inset 0 0 0 2px #ffffff55;transform:rotate(var(--phone-angle));transform-origin:50% 70%}
.phone-body:before,.phone-body:after{content:'';position:absolute;width:4px;background:#707681;border:1px solid #aab1ba;border-radius:4px;left:-5px;top:19%;height:7%}.phone-body:after{left:auto;right:-5px;top:26%;height:10%}
.device-screen{position:relative;width:100%;height:100%;border:3px solid #080b10;border-radius:47px;overflow:hidden;background:#f2f4f8;isolation:isolate}
.device-screen:after{content:'';position:absolute;inset:0;border:1px solid #ffffff20;border-radius:inherit;pointer-events:none;z-index:5}
.phone-status{position:absolute;left:0;right:0;top:0;height:45px;background:#f3f5f9;display:flex;align-items:center;justify-content:space-between;padding:3px 25px 0;font:600 15px Arial,sans-serif;color:#18202a;z-index:3}
.phone-island{position:absolute;left:50%;top:10px;transform:translateX(-50%);width:27%;height:25px;background:#06080b;border-radius:30px;z-index:4}
.phone-status svg{width:56px;height:16px}.phone-browser{position:absolute;left:0;right:0;top:44px;height:42px;background:#e5e9f0;color:#4c5665;display:flex;justify-content:center;align-items:center;font:15px Arial,sans-serif;z-index:2;box-shadow:0 1px 0 #c3cbd5}
.phone-viewport{position:absolute;top:87px;bottom:25px;left:0;right:0;overflow:hidden;background:#edf2fa}
.phone-page{display:block;width:100%;height:auto;max-width:none;object-fit:contain;transform:translateY(var(--phone-pan,0px));transform-origin:50% 0}
.phone-home{position:absolute;left:0;right:0;bottom:0;height:26px;background:#e8edf4;z-index:3}.phone-home:after{content:'';position:absolute;left:35%;right:35%;bottom:8px;height:4px;border-radius:5px;background:#26334180}
.proof-note{position:absolute;left:80px;bottom:63px;width:720px;font-size:28px;line-height:1.25;opacity:.82;margin:0}.footer{position:absolute;right:80px;bottom:63px;font-size:28px;opacity:.82}.reel .proof-note,.reel .footer{bottom:230px}
.statement .headline{top:370px;width:900px;font-size:110px}.statement .detail{top:870px;width:850px;font-size:38px}.statement .rule{position:absolute;left:80px;top:290px;width:120px;height:6px;background:var(--accent)}
.reel.statement .headline{top:500px;width:850px;font-size:120px}.reel.statement .detail{top:1150px;width:800px;font-size:44px}.reel.statement .rule{top:390px}
.end .end-brand{position:absolute;left:80px;top:330px;width:680px;height:auto}.end .end-message{position:absolute;left:80px;top:700px;font-size:80px;line-height:1.1;margin:0;width:920px;padding-bottom:.14em}.end .site{position:absolute;left:80px;top:1000px;font-size:76px;font-weight:740;margin:0}
.reel.end .end-brand{top:440px}.reel.end .end-message{top:930px;font-size:92px}.reel.end .site{top:1400px;font-size:86px}
`;

export function phoneSceneMarkup({id='scene',mode='phone-center',heading,detail='',asset,logo='logo-dark.png',skin='ink',reel=false,note='Example demo - fictional content',counter='',prefix='assets/',subject='',phoneOffset=0}){
 const close=mode==='end',type=mode==='statement';
 return `<div id="${id}-stage" class="canvas ${reel?'reel ':''}${mode} ${skin}"${close?' data-hold':` data-product-subject="${esc(subject)}"`}>
 ${close?`<img class="end-brand" src="${prefix+logo}" alt="Example demo logo"><p class="end-message">Create your page</p><p class="site">example.com</p>`:`<img class="brand" src="${prefix+logo}" alt="Example demo logo"><h1 class="headline">${esc(heading)}</h1><p class="detail">${esc(detail)}</p>${type?'<div class="rule"></div>':`<div class="device-stage" data-phone-offset="${phoneOffset}"><div class="device-ground"></div><div class="phone-body"><div class="device-screen"><div class="phone-status" data-layout-ignore><span data-layout-ignore>9:41</span><svg viewBox="0 0 56 16" aria-hidden="true"><path fill="currentColor" d="M0 12h3v3H0zm5-3h3v6H5zm5-3h3v9h-3zm5-4h3v13h-3z"/><path d="M23 6q6-6 12 0m-10 3q4-4 8 0m-6 3q2-2 4 0" fill="none" stroke="currentColor" stroke-width="1.5"/><rect x="39" y="3" width="14" height="10" rx="2" fill="none" stroke="currentColor"/><rect x="41" y="5" width="10" height="6" rx="1" fill="currentColor"/><path d="M55 6v4" stroke="currentColor" stroke-width="2"/></svg></div><div class="phone-island"></div><div class="phone-browser" data-layout-ignore>example.com</div><div class="phone-viewport"><img class="phone-page" src="${prefix+esc(asset)}" alt="Fictional demonstration page"></div><div class="phone-home"></div></div></div></div>`}<p class="proof-note">${esc(note)}</p>`}
 ${counter?`<div class="footer"><span class="count">${esc(counter)}</span></div>`:''}</div>`;
}
export const phoneFitScript=`function fitPhoneScenes(){for(const e of document.querySelectorAll('.headline')){const room=e.closest('.cover')?200:e.closest('.phone-center')?(e.closest('.reel')?215:190):e.closest('.statement')?430:460;while((e.scrollHeight>room||e.scrollWidth>e.clientWidth+1)&&parseFloat(getComputedStyle(e).fontSize)>48)e.style.fontSize=(parseFloat(getComputedStyle(e).fontSize)-2)+'px';}for(const d of document.querySelectorAll('.device-stage')){const image=d.querySelector('.phone-page'),view=d.querySelector('.phone-viewport'),pan=()=>{const excess=Math.max(0,image.offsetHeight-view.clientHeight);image.style.setProperty('--phone-pan',(-excess*Number(d.dataset.phoneOffset||0))+'px');};if(image.complete)pan();else image.addEventListener('load',pan,{once:true});}}document.fonts.ready.then(fitPhoneScenes);`;
