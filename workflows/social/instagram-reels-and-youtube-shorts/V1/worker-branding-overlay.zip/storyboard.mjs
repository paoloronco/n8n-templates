// Approved hypothetical situations, never customer testimonials or outcome claims.
const stories={
 restaurant:[
  ["Tonight's special just changed.","The menu changes. But yesterday's version is still printed on the table."],
  ['Another place to update.',"The food, the opening hours, and the contact details all need a clear home."],
  ['Change the menu. Keep the link.',"What if you could update the menu without replacing the link people scan?"],
 ],
 creator:[
  ['New work. Another link.',"A new project goes live. Your work now lives in one more place."],
  ['Which link goes in the bio?',"The portfolio is here. The latest release is there. Contact is somewhere else."],
  ['Give it one destination.',"Bring those pieces together, with a visual theme that feels like your work."],
 ],
 studio:[
  ['The work is ready.',"Your latest project is ready to share. Your contact details live somewhere else."],
  ['Then comes the next question.',"Where should someone go to explore your work and find how to reach you?"],
  ['Let the pieces meet.',"Give the projects, the studio information, and the contact links one public home."],
 ],
 events:[
  ['The line-up is announced.',"You have the line-up, the place, the time, and an external ticket link."],
  ['The details are scattered.',"One post has the date. Another has the address. The ticket link is elsewhere."],
  ['Give the night one destination.',"Put the event information and your external ticket link together on one page."],
 ],
 cocktail:[
  ['The evening starts online.',"Someone wants to see the drinks, check the opening hours, and find your bar."],
  ['More than a drinks list.',"The menu is one piece. The location and the information matter alongside it."],
  ['Bring the bar together.',"Give the menu and the information a public page with the links you choose."],
 ],
 property:[
  ['The photos tell one part.',"A property has images, details, and a contact link. Each piece has a purpose."],
  ['Then come the questions.',"Where are the details? Where is the location? How does someone get in touch?"],
  ['Give the details an address.',"Bring the property information, the images, and the contact links into one public page."],
 ],
};
export function storyBeats(job){
 const approved=stories[job.feature.id];if(!approved)throw new Error('No approved story for feature');
 return job.copy.story||approved.map(([heading,line])=>({heading,line}));
}
export function solutionHeading(job){
 return {restaurant:'New menu. Same QR.',creator:'One page for your work.',studio:'Work and contact. Together.',events:'One link for the night.',cocktail:'Your menu. Your character.',property:'The full picture. One page.'}[job.feature.id];
}
export function reelBeats(job){
 const story=storyBeats(job);
 return [
  {role:'hook',heading:job.copy.hook,line:job.copy.hook},
  ...story.map((beat,i)=>({...beat,role:['setup','friction','turn'][i]})),
  {role:'solution',heading:solutionHeading(job),line:job.copy.detail},
  {role:'cta',heading:'Make it yours.',line:'Explore Example. Visit example dot com.'},
 ];
}
