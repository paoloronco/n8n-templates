import { campaign, campaignIndex } from './campaign.mjs';
import {phoneProof} from './phone-proof.mjs';
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function productProof(job,beat=0){
  const {focus}=campaign(job),id=job.feature.id;
  let hero,detail,label;
  if(id==='restaurant'||id==='cocktail'){
    const menu=id==='restaurant'?'restaurant':'cocktail';
    hero=`proof-menu-${menu}-${beat===1||focus==='categories'?'detail':'hero'}.png`;
    if(id==='restaurant'&&focus==='qr'){
      detail='proof-sharing-restaurant.png';label='One QR. The same menu.';
    }else if(id==='cocktail'&&focus==='hours'){
      hero='proof-v2-cocktail-hero.webp';detail=hero;label='Opening time on your bar page';
    }else if(id==='cocktail'&&focus==='about'){
      hero='proof-v2-cocktail-hero.webp';detail='proof-v2-cocktail-contact.webp';label='Practical details before the visit';
    }else if(focus==='dietary'){
      detail=`proof-menu-${menu}-detail.png`;label='Dietary details beside the dish';
    }else{
      detail=`proof-editor-${menu}.png`;label=focus==='categories'?'Categories and menu items':'Edit descriptions and prices';
    }
  }else if(id==='creator'){
    const variant=campaignIndex(job)%2+1;
    hero=`proof-creator-${variant}-${beat===0?'hero':focus==='contact'?'contact':focus==='podcast'?'podcast':'work'}.png`;
    detail=`proof-creator-${variant}-${focus==='contact'?'contact':focus==='podcast'?'podcast':'work'}.png`;
    label=focus==='podcast'?'Podcast beside your other work':focus==='contact'?'Work and contact links':'Selected work and useful links';
  }else{
    const section=id==='events'?'program':id==='property'?'photos':'work';
    hero=`proof-v2-${id}-${beat===0||focus==='about'?'hero':focus==='contact'?'contact':section}.webp`;
    detail=`proof-v2-${id}-${focus==='about'?'hero':focus==='contact'?'contact':section}.webp`;
    label=id==='events'?(focus==='contact'?'Call directly from the event page':'The programme for upcoming nights'):id==='property'?(focus==='contact'?'Contact details beside the listings':'Property photos and their details'):(focus==='contact'?'Contact the studio from its page':focus==='about'?'The studio behind the work':'A selected studio project');
  }
  // Contact campaigns use the contact section itself, below the services/cards.
  if(id!=='events'){
    if(hero.endsWith('-contact.webp'))hero=`proof-v3-${id}-contact.webp`;
    if(detail.endsWith('-contact.webp'))detail=`proof-v3-${id}-contact.webp`;
  }
  if(id==='restaurant'){
    hero='proof-v8-menu-category.png';
    if(focus==='qr')detail='proof-sharing-restaurant.png';
    else if(beat===3&&focus!=='dietary')detail='proof-editor-restaurant.png';
    else detail=focus==='categories'?'proof-v8-menu-category.png':'proof-v8-menu-dish.png';
  }else if(id==='creator'){
    const v=campaignIndex(job)%2+1;
    hero=`proof-v8-creator-${v}-work.png`;
    detail=`proof-v8-creator-${v}-${focus==='contact'?'contact':focus==='podcast'?'podcast':'work'}.png`;
  }else{
    const part=id==='property'?(focus==='contact'?'contact':'card'):id==='studio'?(focus==='about'?'about':focus==='contact'?'contact':'project'):id==='events'?(focus==='about'?'about':focus==='contact'?'contact':'program'):focus==='hours'?'hours':focus==='about'?'contact':'drink';
    hero=`proof-v8-${id}-${part}.png`;detail=hero;
    if(id==='cocktail'&&beat===3&&['categories','menu','prices'].includes(focus))detail='proof-editor-cocktail.png';
  }
  const qr=id==='restaurant'&&focus==='qr';
  const position=id==='creator'?(focus==='contact'?85:focus==='podcast'?43:32):id==='property'?(focus==='contact'?55:48):id==='studio'?(focus==='about'?15:focus==='contact'?60:52):id==='events'?(focus==='about'?15:focus==='contact'?65:62):id==='cocktail'&&focus==='about'?55:focus==='hours'?15:focus==='dietary'?70:focus==='prices'?20:focus==='categories'?58:35;
  return {hero,detail,label,qr,position,...phoneProof(job,beat)};
}

export const proofCSS=`
.product-proof{position:absolute;left:80px;top:680px;width:920px;height:440px;display:flex;align-items:center;gap:46px;--proof-height:440px}
.proof-page{height:var(--proof-height);width:250px;flex:none;display:flex;align-items:center;justify-content:center;margin:0}
.proof-page img{max-width:100%;max-height:100%;width:auto;height:auto;display:block;border-radius:18px;box-shadow:0 18px 44px #0003}
.proof-aside{width:624px;height:100%;display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:24px}
.proof-detail{display:block;max-width:100%;width:auto;height:290px;object-fit:contain;object-position:left center;border-radius:12px}
.proof-aside .proof-detail.crop{width:100%;object-fit:cover;object-position:center var(--proof-position)}
.proof-label{font-size:31px;line-height:1.2;font-weight:650;margin:0;max-width:580px}
.proof-note{font-size:21px;line-height:1.3;opacity:.75;margin:0}
.product-proof.reverse{flex-direction:row-reverse}.reverse .proof-aside{align-items:flex-end;text-align:right}.reverse .proof-detail{object-position:right center}
.reel .product-proof{top:860px;height:760px;--proof-height:760px;gap:50px}
.reel .proof-page{width:355px}.reel .proof-aside{width:515px;gap:34px}.reel .proof-detail{height:430px;max-width:515px}.reel .proof-label{font-size:38px;max-width:515px}.reel .proof-note{font-size:24px}
`;

export function proofVisual(job,beat=0){
  const p=productProof(job,beat),reverse=(campaignIndex(job)+beat)%2===1;
  return `<div class="product-proof post-proof${reverse?' reverse':''}" data-product-subject="${esc(job.feature.id)}" data-product-focus="${esc(campaign(job).focus)}"><figure class="proof-page"><img src="assets/${p.hero}" alt="Fictional demonstration page"></figure><div class="proof-aside"><img class="proof-detail${p.qr?'':' crop'}" style="--proof-position:${p.position}%" src="assets/${p.detail}" alt="${esc(p.label)}"><p class="proof-label">${esc(p.label)}</p><p class="proof-note">Example demo - fictional content</p></div></div>`;
}
